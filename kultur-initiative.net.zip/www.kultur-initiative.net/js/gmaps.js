// ****************************************************************************
//  Steuerung fuer Google-Maps
// ****************************************************************************

var gmStartPoint = new GLatLng(51.34560, 12.40511);
var gmStartZoom = 14;
var gmMinZoom = 14;

// ****************************************************************************
//  Projektfunktionen
// ****************************************************************************

function projSetAddrMap(secID){
	var isMap = false;
	var icon;
   // gmSetOverlayDivId("gMapOverlay");
   var d = document.getElementById("addrMapIcon" + secID);
   if(d) icon = d.firstChild.data;
   icon = icon.replace(/ /g, "");
   icon = (icon=="") ? "" : "pix/" + icon;
   if(icon!="") gmSetIconOptions(32,32,16,28);
   gmSetMarkerOptions(icon, false, 0, 17);
   var d = document.getElementById("addrMapData" + secID);
   if(d){ 
   	var df = d.firstChild.data; 
   	df = df.replace(/ /g, "");
   	var dArr = df.split(";")
   	for(var i=0; i<dArr.length; i++) {
   		dArr[i] = dArr[i].replace(/ /g, "");
   		var cArr = dArr[i].split(",");
   		if(dArr[i] != "") gmAddAddr(cArr, "", 0, "", 0, dArr[i]);
   	}
   	if(df!=""){
   		gmGetAddressMap();
   		isMap = true;
   	}
   }
}

function projResetMap(secID){
   window.setTimeout("addrMap" + secID + ".reset()",100);
}

// Info-Tooltip fuer Zoom-Funktion

function DragZoomInitEvent(mapObj,mapPos){
	mapObj.title = "Klicken und Zoom-Bereich aufziehen..."
}

function DragZoomResetEvent(mapObj,mapPos){
	hideTT(); mapObj.title = ""
}

function DragZoomDragendEvent(mapObj,mapPos){
	hideTT(); mapObj.title = ""
}

// Double-Klick-Zoom ausschalten
function gMapDisableDoubleClickZoom(){
	if(!mapOpen) return false; 
	gmArr[cMap]["map"].disableDoubleClickZoom();
}

// Markermanager ausschalten
function gMapResetMarkermanager(){
	if(!mapOpen) return false; 
	gmArr[cMap]["markermanager"] = "undefined";	
}

// ****************************************************************************
//  Grundfunktionen
// ****************************************************************************

var gmArr = new Array();
var cMap, mapOpen = false;

// Start-Funktion (mapName = eindeutige Karten-ID; divID = ID des Karten-Div; 
// Dezimalzahl fuer Steuerelemente; Uebergabe der Kartenfunktionen...
function gmSetMap(mapName,mapDiv,mapCtrl,useFct,startMap){
	if(arguments.length < 5) startMap = true;
   this.mapCtrl = mapCtrl;
   this.useFct = useFct;
   this.reset = function(){ 
      gmCloseMap(); 
      this.initMap = gmOpenMap(mapName, mapDiv);
      gmSetNewMapCtrl(this.mapCtrl);
      this.useFct();
   }
   if(startMap) this.reset();
}

// Start und Ende der Kartenbearbeitung (xName = eindeutige Karten-ID; divID = ID des Karten-Div)
function gmOpenMap(xName, divID){cMap = xName; mapOpen = gmInitMap(divID); return mapOpen;}
function gmCloseMap(){
	if(gmArr[cMap]){
		var f = gmArr[cMap]["intervalFct"]; for(var i=0; i<f.length; ++i) window.clearInterval(f[i]);
	}
	gmArr = new Array(); cMap = "";	mapOpen = false;
}

// Ausgabe einer Karte: mapFct = Fkt.-Modus auf Grundkarte
function gmGetMap(mapFct){
	if(!mapOpen) return false;
	// Abbruch, wenn Seite ohne Stylesheets angezeigt wird...
	var d = document.getElementById('checkCSS');
	if(d){ if(d.offsetHeight > 0) return false; }
	m = gmArr[cMap]["map"];
	m.addMapType(G_NORMAL_MAP);
	G_NORMAL_MAP.getName = function(short) {
	  if(short) {return "Karte"}
	  return "Strassen";
	}
	m.addMapType(G_HYBRID_MAP);
	G_HYBRID_MAP.getName = function(short) {
	  if(short) {return "Foto"}
	  return "Luftbild";
	}
	// Doppelklick-Zoom
	m.enableDoubleClickZoom()
	// Steuerelemente einblenden
	var mc = gmArr[cMap]["mapCtrl"];
	var mArr = new Array(); while(mc!=0){mArr.push(mc%2); mc=Math.floor(mc/2);}
	m.removeControl(m.dzControl); 
	if(mArr[6]==1){	// special: 1000000 = Einbindung der dragzoom-Erweiterung (Lupen-Fkt.)
		var boxStyleOpts = {opacity: .2, border: "2px solid red" }
		var otherOpts = {
			buttonHTML: "<img src='pix/gmDragzoom.gif'>",
			buttonZoomingHTML: "<img src='pix/gmDragzoom2.gif'>",
			buttonStartingStyle: {width: '22px', height: '22px'},
			overlayRemoveTime: 3000
		};
		var callbacks = {
			buttonclick:function(){},
			dragstart:function(){
				// Spezial: ggf. Div-Overlay zur Verhinderung der Text-Selektion beim Aufziehen des Rahmen
				if(gmArr[cMap]["overlayDiv"] != ""){
   				var b = document.getElementsByTagName("body")[0];
   				var c = document.getElementById("specWrapper");
   				var d = document.getElementById(gmArr[cMap]["overlayDiv"]);
   				var bH = (c.offsetHeight > b.offsetHeight) ? c.offsetHeight : b.offsetHeight;
   				if(window.innerHeight > bH) bH = window.innerHeight;
   				d.style.height = bH + "px";
   				d.style.display = "block";
				}
			},
			dragging:function(x1,y1,x2,y2){},
			dragend:function(nw,ne,se,sw,nwpx,nepx,sepx,swpx){ 
				if(gmArr[cMap]["overlayDiv"] != "") document.getElementById(gmArr[cMap]["overlayDiv"]).style.display = "none";
			}
		};
		var hlpPos = (mArr[5]==1) ? new GSize(26,270) : new GSize(16,115);
		m.dzControl = new DragZoomControl(boxStyleOpts, otherOpts, callbacks);
		m.addControl(m.dzControl, new GControlPosition(G_ANCHOR_TOP_LEFT,hlpPos));
	}
	m.removeControl(m.lmControl); m.lmControl = new GLargeMapControl();
	if(mArr[5]==1) m.addControl(m.lmControl);					// 0100000 Richtung u. Groesse max.
	m.removeControl(m.smControl); m.smControl = new GSmallMapControl();
	if(mArr[4]==1) m.addControl(m.smControl);					// 0010000 Richtung u. Groesse Std.
	m.removeControl(m.szControl); m.szControl = new GSmallZoomControl();
	if(mArr[3]==1) m.addControl(m.szControl);					// 0001000 nur Zoom (+-)
	m.removeControl(m.scControl); m.scControl = new GScaleControl();
	if(mArr[2]==1) m.addControl(m.scControl);					// 0000100 Massstab
	m.removeControl(m.mtControl); m.mtControl = new GMapTypeControl();
	if(mArr[1]==1) m.addControl(m.mtControl);					// 0000010 Kartentyp
	m.removeControl(m.omControl); m.omControl = new GOverviewMapControl();
	if(mArr[0]==1) m.addControl(m.omControl);					// 0000001 Uebersichtskarte
	gmArr[cMap]["init"] = true;
	// Events
	GEvent.addListener(m, "click", function(marker, point) {
		if(typeof MapClickEvent == "function") MapClickEvent(marker, point);
	});
	GEvent.addListener(m, "dblclick", function(marker, point) {
		if(typeof MapDblClickEvent == "function") MapDblClickEvent(marker, point);
	});
	// Funktionen
	if(arguments.length < 1) mapFct = "";
	gmArr[cMap]["mapFct"] = mapFct;
	if(!gmAddMapFct(mapFct)) { m.setCenter(gmStartPoint, gmStartZoom); }
	return true;
}

// Hinzufuegen von Karten-Funktionen
function gmAddMapFct(mapFct){
var delay = (document.all) ? 1000 : 200;
switch(mapFct){	
	case "polylineEditor" :	return gmPolylineEditor();
	case "markers" : 			return gmWriteMarkers(); 
	case "directions" : 		window.setTimeout("gmGetDir();", delay); return true;
	case "kmlOverlay" : 		window.setTimeout("gmGetKmlOverlay();", 2*delay); return true;
	case "polyline" : 		window.setTimeout("gmGetPolyline();", delay); return true;
	default : 					return false;
}}

// Neu setzen der MapFkt.
function gmSetNewMapFct(x){if(!mapOpen) return false; gmArr[cMap]["mapFct"] = x;}

// Neu setzen der Steuerelemente
function gmSetNewMapCtrl(x){if(!mapOpen) return false; gmArr[cMap]["mapCtrl"] = x;}

// Neu-Initalisierung der Karte: 
// divID = ID eines Container fuer das Karten-DIV; divClass = Aenderung der CSS-Klasse fuer Karten-DIV
function gmResetMap(divID, divClass){
if(gmArr[cMap]["init"]){
	if(arguments.length < 2) divClass = "";
	if(arguments.length < 1) divID = "";
	if(divID!="") document.getElementById(divID).appendChild(gmArr[cMap]["map"].getContainer());
	if(divClass!="") document.getElementById(gmArr[cMap]["divID"]).className = divClass;
	gmArr[cMap]["map"].checkResize();
	return gmGetMap(gmArr[cMap]["mapFct"], gmArr[cMap]["mapCtrl"]);
}}

// ****************************************************************************
//  Steuerung der Kartenfunktionen
// ****************************************************************************

// Overlay-Div fuer DragZoom setzen (verhindert im IE die normale Text-Selektion)
function gmSetOverlayDivId(x){ if(!mapOpen) return false; gmArr[cMap]["overlayDiv"] = x; }

// Karte automatisch einpassen (true|false)
function gmSetAutoZoom(x){ if(!mapOpen) return false; gmArr[cMap]["disabledAutoZoom"] = !x; }

// --- Adressen ---

// neues Adress-Array
function gmSetNewAddressArr(){ 
	if(!mapOpen) return false; 
	gmArr[cMap]["addrArr"] = new Array();
}

// Adressdaten gesammelt hinzufuegen (adresse, marker-text, mode_marker, error-text, mode_error, marker-title)
function gmAddAddr(a, m, mm, e, me, t){
	if(!mapOpen) return false;
	if(arguments.length < 6) t = (typeof a == "object") ? "" : a;
	if(arguments.length < 5) me = 0;
	if(arguments.length < 4) e = "";
	if(arguments.length < 3) mm = 0;
	if(arguments.length < 2) m = "";
	m = (mm==1) ? document.getElementById(m).innerHTML : m;
	e = (me==1) ? document.getElementById(e).innerHTML : e;
	p = (typeof a == "object") ? new GLatLng(a[0],a[1]) : null;
	gmArr[cMap]["addrArr"][gmArr[cMap]["addrArr"].length] = {
		address: a,
		point: p,
		title: t,
		infoHTML: m,
		errHTML: e,
		icon: gmArr[cMap]["markerIcon"],
		draggable: gmArr[cMap]["markerDraggable"],
		minZoom: gmArr[cMap]["markerMinZoom"],
		maxZoom: gmArr[cMap]["markerMaxZoom"],
		bouncy: gmArr[cMap]["markerBouncy"],
		gravity: gmArr[cMap]["markerBounceGravity"]
}}

// gmSetAddressMarkers ausfuehren
function gmGetAddressMap(){
	gmSetAddressMarkers(function(){ gmGetMap("markers") });
}

// Marker-Optionen (icon, draggable, minZoom, maxZoom, bouncy, bouncyGravity)
function gmSetMarkerOptions(i, d, minZ, maxZ, b, bg){
	if(!mapOpen) return false;
	if(arguments.length > 0) gmArr[cMap]["markerIcon"] = i;					// Dateiname des Bildes
	if(arguments.length > 1) gmArr[cMap]["markerDraggable"] = d;			// true | false
	if(arguments.length > 2) gmArr[cMap]["markerMinZoom"] = minZ;			// 0 - 17
	if(arguments.length > 3) gmArr[cMap]["markerMaxZoom"] = maxZ;			// 0 - 17
	if(arguments.length > 4) gmArr[cMap]["markerBouncy"] = b;				// true | false
	if(arguments.length > 5) gmArr[cMap]["markerBounceGravity"] = bg;		// number
}

// Icon-Optionen fuer gmArr[cMap]["markerIcon"]
function gmSetIconOptions(sizeX,sizeY,anchX,anchY,infoX,infoY,shadX,shadY){
	if(!mapOpen) return false;
	if(arguments.length < 1) sizeX = 32;
	if(arguments.length < 2) sizeY = 32;
	if(arguments.length < 3) anchX = Math.round(sizeX/2);
	if(arguments.length < 4) anchY = Math.round(sizeY/2);
	if(arguments.length < 5) infoX = anchX;
	if(arguments.length < 6) infoY = anchY;
	if(arguments.length < 7) shadX = 59;
	if(arguments.length < 8) shadY = 32;
	gmArr[cMap]["markerIconOptions"] = new gmGetIconOptions(sizeX,sizeY,anchX,anchY,infoX,infoY,shadX,shadY);
}

// --- Routen  ---

// Basis-Adresse fuer gmGetDir() setzen
function gmInitDirBaseAddress(x){if(!mapOpen) return false; gmArr[cMap]["dirBaseAddress"] = x;}

// Ziel-Adresse fuer gmGetDir() setzen
function gmInitDirTargetAddress(x){if(!mapOpen) return false; gmArr[cMap]["dirTargetAddress"] = x;}

// Richtung umkehren? fuer gmGetDir()
function gmInitDirReverse(x){if(!mapOpen) return false; gmArr[cMap]["reverseDir"] = x;}

// Div fuer Text-Ausgabe der Routenbeschreibung setzen; fuer gmGetDir()
function gmInitDirResultDivID(x){if(!mapOpen) return false; gmArr[cMap]["dirResultDivID"] = x;}


// --- KML-Overlays ---

// Datei-Name fuer gmGetKmlOverlay() setzen
function gmInitKmlOverlay(x){if(!mapOpen) return false; gmArr[cMap]["kmlFile"] = x;}


// --- Polylinen ---

// Polyline-Optionen (Linienfarbe, Linienstaerke, Linien-Opacity, Fuellfarbe, Flaechen-Opacity)
function gmSetPolylineOptions(c, w, o, fc, fo){
	if(!mapOpen) return false;
	if(arguments.length > 0) gmArr[cMap]["polylineColor"] = c;				// Hex-Farbe "#000000" der Linie
	if(arguments.length > 1) gmArr[cMap]["polylineWeight"] = w;				// Pixelbreite der Linie
	if(arguments.length > 2) gmArr[cMap]["polylineOpacity"] = o;			// Durchsichtigkeit der Linie (0 - 1)
	if(arguments.length > 3) gmArr[cMap]["polylineFillColor"] = fc;		// Farbe der Flaeche
	if(arguments.length > 4) gmArr[cMap]["polylineFillOpacity"] = fo;		// Durchsichtigkeit der Flaeche
}

// ****************************************************************************
//  Kartenfunktionen (automatischer Aufruf)
// ****************************************************************************

// Initialisierung (wird automatisch aufgerufen)
function gmInitMap(divID){
if(typeof gmArr[cMap] != "object" && GBrowserIsCompatible()) {
	gmArr[cMap] = new Array();
	gmArr[cMap]["map"] = new GMap2(document.getElementById(divID),{mapTypes:[]});
	gmArr[cMap]["divID"] = divID;
	gmArr[cMap]["mapCtrl"] = 18;	// Std. 0010010 = Richtung und Groesse + Kartentyp
	gmArr[cMap]["init"] = false;
	// Array fuer Dauerfkt. auf der Map
	gmArr[cMap]["intervalFct"] = new Array();
	// alle Marker der Map
	gmArr[cMap]["markers"] = new Array();
	gmArr[cMap]["markersHTML"] = new Array();
	gmArr[cMap]["markerPoints"] = new Array();
	// Einstellungen fuer gmWriteMarkers(), falls nicht alle Marker gezeigt werden sollen
	gmArr[cMap]["markersZoom"] = 0;	// markersCenterPoint wird bei > 0 verwendet
	gmArr[cMap]["markersCenterPoint"] = gmStartPoint;
	gmArr[cMap]["disabledAutoZoom"] = false;
	gmArr[cMap]["useMarkermanager"] = true;
	// Einstellungen fuer Marker-Generierung
	gmArr[cMap]["markerIcon"] = ""; 
	gmSetIconOptions();
	gmArr[cMap]["markerDraggable"] = false;
	gmArr[cMap]["markerBouncy"] = true;
	gmArr[cMap]["markerBounceGravity"] = 1;
	gmArr[cMap]["markerMinZoom"] = 0;
	gmArr[cMap]["markerMaxZoom"] = 17;
	// Adressen
	gmArr[cMap]["addrOutCounter"] = 0;
	gmArr[cMap]["addrArr"] = new Array();
	// Routen
	gmArr[cMap]["dirBaseAddress"] = "";
	gmArr[cMap]["dirTargetAddress"] = ""
	gmArr[cMap]["reverseDir"] = false;
	gmArr[cMap]["dirResultDivID"] = "";
	// KML
	gmArr[cMap]["kmlOutCounter"] = 0;
	gmArr[cMap]["kmlFile"] = "";
	// alle Polylinien der Map
	gmArr[cMap]["polylines"] = new Array()
	gmArr[cMap]["polylineTracks"] = new Array();
	gmArr[cMap]["polylineBounds"] = null;
	gmArr[cMap]["polylineCounter"] = 0;
	// Einstellungen fuer Polylinien
	gmArr[cMap]["polylineColor"] = "#006600";
	gmArr[cMap]["polylineWeight"] = 4;
	gmArr[cMap]["polylineOpacity"] = 1;
	gmArr[cMap]["polylineFillColor"] = "";
	gmArr[cMap]["polylineFillOpacity"] = 0.5;
	return true;
}
return false;
}

// ----------------------------------------------------------------------------

// Route anzeigen; Aufruf ueber gmGetMap()
function gmGetDir(){
if(!mapOpen) return false;
if (gmArr[cMap]["init"]) {	
	if(gmArr[cMap]["directions"]) gmArr[cMap]["directions"].clear();
	gmArr[cMap]["map"].setCenter(gmStartPoint, gmStartZoom);
	if(gmArr[cMap]["dirResultDivID"]!="")
		gmArr[cMap]["directions"] = new GDirections(gmArr[cMap]["map"], document.getElementById(gmArr[cMap]["dirResultDivID"]));
	else
		gmArr[cMap]["directions"] = new GDirections(gmArr[cMap]["map"]);
	var f = (gmArr[cMap]["reverseDir"]) ? gmArr[cMap]["dirTargetAddress"] : gmArr[cMap]["dirBaseAddress"];
	var t = (gmArr[cMap]["reverseDir"]) ? gmArr[cMap]["dirBaseAddress"] : gmArr[cMap]["dirTargetAddress"];
	gmArr[cMap]["directions"].load("from: " + f + " to: " + t, {"locale": "de"});
	return true;
}}

function gmResetDirResult(divClass){
	if(arguments.length < 1) divClass = "";
   if(gmArr[cMap]["dirResultDivID"]!="") document.getElementById(gmArr[cMap]["dirResultDivID"]).innerHTML = "";
   if(divClass!="") document.getElementById(gmArr[cMap]["divID"]).className = divClass;
   if(gmArr[cMap]["directions"]) gmArr[cMap]["directions"].clear();
}

// ----------------------------------------------------------------------------

// Adressen im adrArr auswerten und Adress-Marker setzen (ruft sich selbst rekursiv auf); 
// zum Abschluss wird eine in resFct uebergebene Funktion ausgefuehrt...
function gmSetAddressMarkers(resFct){
if(!mapOpen) return false;

	// *** ggf. letzten Adresspunkt auswerten ***
	var i = gmArr[cMap]["addrOutCounter"] - 1; 
	if(i>=0){
		var cp = gmArr[cMap]["cMarkerPoint"];
		var ao = gmArr[cMap]["addrArr"][i];
		var cOpt = new gmMarkerOptions(ao.title, ao.icon, ao.draggable, ao.bouncy, ao.gravity);
		if(cp==null){		// Adresse nicht gefunden
			cp = gmStartPoint;
			if(!ao.errHTML) ao.errHTML = "<" + "div class='mapMarker'>Die Adresse (" + ao.address + ") wurde nicht erkannt und kann in der Karte nicht angezeigt werden.</" + "div>"
			ao.infoHTML = ao.errHTML;
			cOpt.icon = gmGetGIcon("pix/gmError.gif");
		}
		if(cp!=null){
			ao.point = cp;
			if(typeof gmArr[cMap]["markers"][cp] != "object") gmArr[cMap]["markerPoints"].push(cp);
			gmArr[cMap]["markers"][cp] = {
				marker: new GMarker(cp, cOpt), 
				infoHTML: ao.infoHTML, 
				minZoom: ao.minZoom,
				maxZoom: ao.maxZoom
			}
			if(ao.infoHTML!=""){
				gmArr[cMap]["markers"][cp].marker.testHTML = ao.infoHTML;
				GEvent.addListener(gmArr[cMap]["markers"][cp].marker, "click", 
					function() {
					gmArr[cMap]["map"].closeInfoWindow();
					this.openInfoWindowHtml(this.testHTML);
				});
			}
		}
	}
	// *** ggf. Ende, wenn alle Addr. bearbeitet sind ***
	if(gmArr[cMap]["addrOutCounter"] >= gmArr[cMap]["addrArr"].length){
		gmArr[cMap]["addrOutCounter"] = 0; 
		if(typeof resFct == "function") resFct();
		return true;
	}else{
		// ** rekursiver Aufruf ***
		var i = gmArr[cMap]["addrOutCounter"]; 
		gmArr[cMap]["addrOutCounter"] += 1;
		// Addr.Punkt uebernehmen oder per Geocoder holen + rekursiver Aufruf
		gmArr[cMap]["cMarkerPoint"] = null;
		if(gmArr[cMap]["addrArr"][i].point!=null){
			gmArr[cMap]["cMarkerPoint"] = gmArr[cMap]["addrArr"][i].point; 
			gmSetAddressMarkers(resFct);
		} else {
			var geocoder = new GClientGeocoder();
			geocoder.setBaseCountryCode("de");
			geocoder.getLatLng(
				gmArr[cMap]["addrArr"][i].address, 
				function(point){ if(point) gmArr[cMap]["cMarkerPoint"] = point; gmSetAddressMarkers(resFct);
			});
		}
	}
}

// titel, icon, draggable, bouncy, bouncyGravity
function gmMarkerOptions(t, i, d, b, bg){
if(!mapOpen) return false;
	if(arguments.length < 5) bg = gmArr[cMap]["markerBounceGravity"];
	if(arguments.length < 4) b = gmArr[cMap]["markerBouncy"];
	if(arguments.length < 3) d = gmArr[cMap]["markerDraggable"];
	if(arguments.length < 2) i = gmArr[cMap]["markerIcon"];
	if(arguments.length < 1) t = "";
	if(t!="") this.title = t;
	this.icon = (i!="") ? gmGetGIcon(i) : G_DEFAULT_ICON;
	if(d){ this.draggable = d; this.bouncy = b; if(bg!=1) this.bounceGravity = bg; }
}

function gmGetIconOptions(sizeX,sizeY,anchX,anchY,infoX,infoY,shadX,shadY){
	this.sizeX = sizeX; this.sizeY = sizeY;
	this.shadX = shadY; this.shadY = shadY;
	this.anchX = anchX; this.anchY = anchY;
	this.infoX = infoX; this.infoY = infoY;
}

function gmGetGIcon(x){
	if(typeof gmArr[cMap]["markerIconOptions"] != "object") gmSetIconOptions();
	var o = gmArr[cMap]["markerIconOptions"];
	var icon = new GIcon(); 
		icon.image = x;
		icon.iconAnchor = new GPoint(o.anchX, o.anchY);
		icon.infoWindowAnchor = new GPoint(o.infoX, o.infoY);
		icon.iconSize = new GSize(o.sizeX, o.sizeY);
		icon.shadow = x.replace(/\./, "_shadow.");
		icon.shadowSize = new GSize(o.shadX, o.shadY);
	return icon;
} 

function gmWriteMarkers(){
if(!mapOpen) return false;
if (gmArr[cMap]["init"] && gmArr[cMap]["markerPoints"].length > 0) {

	var gm = gmArr[cMap], map = gm["map"];
	
	// ggf. einen einzelnen Marker direkt darstellen
	if(gm["markerPoints"].length == 1){
		var cp = gm["markerPoints"][0];
		if(!gm["disabledAutoZoom"]) map.setCenter(cp, gmMinZoom);
		map.addOverlay(gm["markers"][cp].marker);
		if(gm["markers"][cp].infoHTML!="")
			map.openInfoWindowHtml(cp, gm["markers"][cp].infoHTML);
		return true;
	}
		
	// minimales Ansichtsfenster
	if(!gm["disabledAutoZoom"]) map.setCenter(gm["markerPoints"][0], 17);
	gm["bounds"] = map.getBounds();
	
	// ggf. Marker-Manager erstellen
	if(typeof gm["markermanager"] != "object" && gm["useMarkermanager"]){
		gm["markermanager"] = new GMarkerManager(map, { borderPadding: 50, trackMarkers: true });
	}

	// Marker schreiben...
	for (var i = 0; i < gm["markerPoints"].length; ++i) {
		var cp = gm["markerPoints"][i];
		gm["bounds"].extend(cp);
		if (gm["useMarkermanager"]) {
			gm["markermanager"].addMarker(gm["markers"][cp].marker, gm["markers"][cp].minZoom, gm["markers"][cp].maxZoom);
		} else {
			map.removeOverlay(gm["markers"][cp].marker);
			map.addOverlay(gm["markers"][cp].marker);
		}
	}
	
	// Ansicht einpassen
	if(!gm["disabledAutoZoom"]){
		if(gm["markersZoom"] > 0) {
			map.setCenter(gm["markersCenterPoint"], gm["markersZoom"]);
		} else {
			var delay = (document.all) ? 1000 : 500;
			window.setTimeout("gmMarkersAutoZoom()", delay);
		}
 	}
 	return true;
}}

function gmMarkersAutoZoom(){
	var gm = gmArr[cMap], map = gm["map"];
	if(gm["markermanager"].getMarkerCount(map.getBoundsZoomLevel(gm["bounds"])) > 1){
		map.setZoom(map.getBoundsZoomLevel(gm["bounds"]));
		map.setCenter(gm["bounds"].getCenter());
	} else {
		map.setZoom(gmStartZoom);
	}	
}

// ----------------------------------------------------------------------------

// Overlay einer KML-Datei
function gmGetKmlOverlay(){
if(!mapOpen) return false;
if (gmArr[cMap]["init"]) {	
	// Vorbereitungen; Daten pruefen + ggf. Abbruch 
	var cf = gmArr[cMap]["kmlFile"]; if(cf == "") return false;
	if(typeof gmArr[cMap]["kmlOverlays"] != "object")
		gmArr[cMap]["kmlOverlays"] = new Array();
	// Ansicht einstellen
	gmArr[cMap]["map"].setCenter(gmStartPoint, gmStartZoom);
	gmArr[cMap]["kmlOverlays"][cf] = new GGeoXml(cf, function() {
		if(gmArr[cMap]["kmlOverlays"][cf].loadedCorrectly()) {
			if(!gmArr[cMap]["disabledAutoZoom"])
				gmArr[cMap]["kmlOverlays"][cf].gotoDefaultViewport(gmArr[cMap]["map"]);
			if(!document.all) gmArr[cMap]["map"].addOverlay(gmArr[cMap]["kmlOverlays"][cf]);
		}
	 });
	 if(document.all)
	 	window.setTimeout("gmArr[cMap]['map'].addOverlay(gmArr[cMap]['kmlOverlays'][gmArr[cMap]['kmlFile']]); ", 10);
	 GEvent.addListener(gmArr[cMap]["map"], "click", function(){
	 	// gmArr[cMap]["map"].addOverlay(gmArr[cMap]["kmlOverlays"][gmArr[cMap]["kmlFile"]]);
	});
}}

// ----------------------------------------------------------------------------

// Punkte fuer Polylinie holen (bei mode = 1 aus HTML-Element, sonst direkt)
function gmInitPolyline(name, x, mode){
if(arguments.length < 3) mode = 0;
if(!mapOpen) return false;
	// Vorbereitungen
	var xStr = (mode==1) ? document.getElementById(x).innerHTML : x;
	if(xStr=="") return false;
	xStr = xStr.replace(/\s/,"");
	var ptArr = xStr.split(";")
	var cp = gmArr[cMap]["polylines"].length
	gmArr[cMap]["polylines"][cp] = {
		name: name,
		counter: 0,
		color: gmArr[cMap]["polylineColor"],
		weight: gmArr[cMap]["polylineWeight"],
		opacity: gmArr[cMap]["polylineOpacity"],
		fillColor: gmArr[cMap]["polylineFillColor"],
		fillOpacity: gmArr[cMap]["polylineFillOpacity"],
		points: new Array(), 
		polygon: {},
		bounce: null,
		trackHlp: new Array()
	}
	// Punkt-Array erzeugen
	for (var i = 0; i < ptArr.length; ++i) {
		var pt = ptArr[i].split(",");
		if(pt.length==2 || pt.length==3){ 
			if(!(isNaN(pt[0]) && isNaN(pt[1]))) 
				gmArr[cMap]["polylines"][cp].points.push(new GLatLng(pt[1],pt[0]));
		}
	}
}

// Polyline in Teilstuecke zerlegt erzeugen (ruft sich selbst rekursiv auf);
function gmGetPolyline(){
var map = gmArr[cMap]["map"];
var numb = gmArr[cMap]["polylineCounter"];
var mapTrack = gmArr[cMap]["polylineTracks"];

// ---- Einzelne Polylinie erstellen ----

if(numb<gmArr[cMap]["polylines"].length){
	var cp = gmArr[cMap]["polylines"][numb];
	if (gmArr[cMap]["init"] && cp.points.length > 0) {
		var i = cp.counter;
		// letzte Linie ausgeben oder minimales Ansichtsfenster
		if(i>0) {
			// Teilstueck erzeugen
			gmArr[cMap]["polylineBounds"].extend(cp.points[i]);
			cp.trackHlp.push(cp.points[i]);
			mapTrack[mapTrack.length] = new GPolyline(cp.trackHlp, cp.color, cp.weight, cp.opacity);
		} else {
			// ggf. Ansicht auf ersten Punkt
			if(gmArr[cMap]["polylineBounds"] == null){
				if(!gmArr[cMap]["disabledAutoZoom"]) 
					map.setCenter(cp.points[0], 17);
				else
					map.setCenter(gmStartPoint, gmStartZoom);
				gmArr[cMap]["polylineBounds"] = map.getBounds();
			}
		}
		// Neues Teilstueck beginnen
		cp.trackHlp = new Array();
		cp.trackHlp.push(cp.points[i]);
		i+=1; 
		// ggf. rekursiver Aufruf fuer aktuelle Polylinie
		if(i<cp.points.length){
			cp.counter = i;
			window.setTimeout("gmGetPolyline();", 10);
			return null;
		}
		cp.counter = 0;
		// ggf. Polygon fuer aktuelle Polylinie ausgeben
		if(cp.fillColor != ""){
			cp.polygon = new GPolygon(cp.points, "", 0, 1, cp.fillColor, cp.fillOpacity);
			map.addOverlay(cp.polygon);
		}
	}
	// rekursiver Aufruf fuer naechste Polyline
	gmArr[cMap]["polylineCounter"] += 1;
	gmGetPolyline();

// ---- alle erstellen Polylinien ausgeben ----

} else {
	
	// Ansicht einstellen
	if(!gmArr[cMap]["disabledAutoZoom"]){
		map.setZoom(map.getBoundsZoomLevel(gmArr[cMap]["polylineBounds"]));
  		map.setCenter(gmArr[cMap]["polylineBounds"].getCenter());
  	}
	
	// Werte zuruecksetzen
	gmArr[cMap]["polylineCounter"] = 0;
	gmArr[cMap]["polylineBounds"] = null;
	
  	// Teilstuecke ausgeben
  	gmWritePolyline();
	
	// regelmaessige Pruefung, ob Neu-Zeichnen der Polylinie noetig ist...
	gmArr[cMap]["intervalFct"].push(window.setInterval("checkZoomForPolyline();", 500));
	
	// fertig
	return true;
}}

// Polylinie nach jeder Kartenaenderung neu zeichnen... (insbesondere fuer IE)
function checkZoomForPolyline(){
	var m = gmArr[cMap]; m["bounds"] = m["map"].getBounds(); 
	if (!m["bounds"].equals(m["polylineBounds"])){
		if(typeof m["boundsHlp"] == "object"){
			if(m["bounds"].equals(m["boundsHlp"])){ 
				m["polylineCounter"] = 0; 
				window.setTimeout("gmWritePolyline();",10);
			}
		}
		m["boundsHlp"] = m["bounds"];
	}
}

// Ausgabe der erzeugten Polyline-Teilstuecken (ruft sich selbst rekursiv auf)...
function gmWritePolyline(){
var writeDelay = 10; 	// Verzoegerung beim zeichnen
var m = gmArr[cMap]['map']; 
var mapTrack = gmArr[cMap]["polylineTracks"];
var i = gmArr[cMap]["polylineCounter"];
gmArr[cMap]["polylineBounds"] = gmArr[cMap]["map"].getBounds();
if(i<mapTrack.length){
  		gmArr[cMap]["polylineCounter"] += 1;
  		window.setTimeout("gmWritePolyline();",writeDelay);
  		m.removeOverlay(mapTrack[i]);
  		m.addOverlay(mapTrack[i]);
	} else {
		gmArr[cMap]["polylineCounter"] = 0;
		return true;
	}
}

// ----------------------------------------------------------------------------

function gmPolylineEditor(){
	gmSetMarkerOptions("", 1, 0, 17, 0, 0);
	
	// Event
	GEvent.addListener(m, "click", function(marker, point) {
		gmArr[cMap]["disabledAutoZoom"] = true;		// $$$$$$$$$$$$$$$$$$$$$$$$$$$$$
		gmArr[cMap]["useMarkermanager"] = false;			// $$$$$$$$$$$$$$$$$$$$$$$$$$$$$
		gmAddEditorPoint(marker, point);
		// gmArr[cMap]["map"].setCenter(point);
	});
}

function gmAddEditorPoint(marker, point){

	if(point){
		var cOpt = new gmMarkerOptions("Punkt " + point);
		if(typeof gmArr[cMap]["markers"][point] != "object") gmArr[cMap]["markerPoints"].push(point);
		gmArr[cMap]["markers"][point] = {
			marker: new GMarker(point, cOpt), 
			infoHTML: "", 
			minZoom: 0,
			maxZoom: 17
		}
		// $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
		// $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
		gmWriteMarkers();
		// gmArr[cMap]["markers"][point].marker.basePt = point + " Test"
		// GEvent.addListener(gmArr[cMap]["markers"][point].marker, "click", function() {
		//	alert(this.basePt);
			// gmArr[cMap]["markers"][this.basePt] = null;
			// gmArr[cMap]["disabledAutoZoom"] = true;
			// gmWriteMarkers();
		// });
	}
}

// ----------------------------------------------------------------------------

function gmAddMarkerPoint(point, mOpt){
	if(!mapOpen) return false;
	if(!point) return false;
	if(arguments.length < 2) var mOpt = new gmMarkerOptions("Punkt " + point);
	gmArr[cMap]["markers"][point] = {
		marker: new GMarker(point, mOpt)
	}
	gmArr[cMap]["map"].addOverlay(gmArr[cMap]["markers"][point].marker);
}

function gmDelMarkerPoint(point){
	if(!mapOpen) return false;
	if(!point) return false;
	gmArr[cMap]["map"].removeOverlay(gmArr[cMap]["markers"][point].marker);
	gmArr[cMap]["markers"][point] == "undefined";
}

function gmDelMarkerPoint_BAK(point){
	if(!mapOpen) return false;
	if(!point) return false;
	var x = 0
	for(var i=0; i < gmArr[cMap]["markerPoints"].length; i++){
		if(gmArr[cMap]["markerPoints"][i]==point) x++;
		gmArr[cMap]["markerPoints"][i] = gmArr[cMap]["markerPoints"][i+x];
	}
	gmArr[cMap]["markerPoints"].length = gmArr[cMap]["markerPoints"].length - x;
	gmArr[cMap]["map"].removeOverlay(gmArr[cMap]["markers"][point].marker);
	gmArr[cMap]["markers"][point] == "undefined";
}



