var xPos = 0, yPos = 0, goPos = 0; 
var showTabRowDelay, cTTObj, cTitle, tooltipFlag, xPosOffset, yPosOffset;

if(top.frames.length > 0 && self.name!="fileMngPreview" && self.name!="specProjFrame"){top.location.href=self.location;}

// ---------------------------------- Projekt ----------------------------------

function initAll(){
}

function exitAll(){
}

// ---------------------------------- Events ----------------------------------

document.onmousedown = getPos;
document.onmousemove = setShowDivPos;

function checkScrollPos(){
	if(window.name.indexOf('pos')!=-1){
		window.scrollBy(0,parseInt(window.name.slice(3)));
		window.name='cont';
	}
}

function getPos(e){
	if(document.all){
		xPos = (document.compatMode=='CSS1Compat') ? window.event.clientX + document.documentElement.scrollLeft : window.event.clientX + document.body.scrollLeft;
		yPos = (document.compatMode=='CSS1Compat') ? window.event.clientY + document.documentElement.scrollTop : window.event.clientY + document.body.scrollTop;
	}else{	/* pageXY = Fensterrelativ / screenXY = Bildschirmabsolut */
		xPos = e.pageX;
		yPos = e.pageY;
	}
	document.body.scrollTop ? goPos = document.body.scrollTop : goPos = window.pageYOffset;
	if(goPos==null) goPos=0;
}

function clPos(){window.name="pos" + goPos;}

function setShowDivPos(e){
if(tooltipFlag){
	getPos(e);
	var sD = document.getElementById("tooltipDiv");
	sD.style.left = (xPos + xPosOffset) + "px";
	sD.style.top = (yPos + yPosOffset) + "px";
}}

// --------------------------------- Standard ---------------------------------

function topInfo(cont,target,w,h)
{var topInf = window.open(cont,target,'width='+w+',height='+h+',dependent=yes,resizable=yes,scrollbars=yes,menubar=yes,status=yes'); topInf.focus(); return false;}
function openCal(target,obj){var openCal = window.open (target, 'topCal', 'width=200,height=280,dependent=yes,resizable=yes,scrollbars=no,top='+(yPos-150)+',left='+(xPos-100)); openCal.focus();}

// ------------------------------------ Navi ----------------------------------

var showNaviDelay, subNaviFlag;

document.onmousedown = execCloseSubNavi;

function showSubNavi(o,x){
	if(typeof subNaviDisabled == "boolean"){
		if(subNaviDisabled) return false;
	};
	var p = getObjPosById(o); if(document.all) p.top -= 1;
	var snObj = document.getElementById(x);
	clearTimeout(showNaviDelay);
	subNaviFlag = true;
	var fd = document.getElementById("mouseOverNaviDiv");
	fd.innerHTML = snObj.innerHTML;
	fd.style.left = p.left + o.offsetWidth + "px";
	fd.style.top = p.top + "px";
	fd.style.display = "block";
	return true;
}

function closeSubNavi(){
	subNaviFlag = false;
	showNaviDelay = setTimeout("execCloseSubNavi()",900);
}

function holdSubNavi(){
	subNaviFlag = true;
	clearTimeout(showNaviDelay);
}

function execCloseSubNavi(){
	if(subNaviFlag) return false;
	clearTimeout(showNaviDelay);
	var fd = document.getElementById("mouseOverNaviDiv");
	fd.style.display = "none";
	fd.innerHTML = "";
	fd.style.left = "0px";
	fd.style.top = "0px";
	return true;
}

function getObjPosById(o){
	var p = {left:0, top:0};
	if(typeof o != "object") return p;

	if(typeof o.offsetLeft != 'undefined'){
		while(o) {
			 p.left += o.offsetLeft;
			 p.top += o.offsetTop;
			 o = o.offsetParent;
		}
	} else {
		p.left = o.left ;
		p.top = o.top ;
	}
	return p;
}

// ----------------------------------- Tooltip --------------------------------

function hideTooltip(){
	clearTimeout(showTabRowDelay);
	document.getElementById("tooltipDiv").style.display = "none";
	tooltipFlag = false;
}

function uncoverTooltip(){
	document.getElementById("tooltipDiv").style.display = "block";
}

function showTT(obj,x){
	if(x!="") var ttNode = document.getElementById(x).firstChild;
	var ttTxt; 
	ttNode ? ttTxt = ttNode.nodeValue : ttTxt = obj.title;
	
	cTTObj = obj; cTitle = obj.title; obj.title = ""; 
	var sD = document.getElementById("tooltipDiv");
	var sDf = sD.firstChild;
	while (sDf!=null){
		sD.removeChild(sDf); 
		sDf = sD.firstChild;}
	if(ttTxt!=null && ttTxt!=""){
		var newEntry = document.createTextNode(ttTxt);
		sD.appendChild(newEntry);
		tooltipFlag = true; xPosOffset = 15; yPosOffset = 20;
		showTabRowDelay = setTimeout("uncoverTooltip()",500);}
}

function hideTT(){
	if(cTTObj!=null) {cTTObj.title = cTitle; cTTObj = null; cTitle = "";}
	hideTooltip(); 
}

function showTabRow(xy){ 
	clearTimeout(showTabRowDelay);
	var sD = document.getElementById("tooltipDiv");
	var sDf = sD.firstChild;
	var xNode = xy.firstChild;
	while (sDf!=null){
		sD.removeChild(sDf);
		sDf = sD.firstChild;}
	var counter = 0; 
	while (xNode!=null){
		if(xNode.nodeType==1 && xNode.childNodes[0].nodeValue!=null){
			counter+=1; 
			var xNV = xNode.childNodes[0].nodeValue
			var newEntry = document.createTextNode(counter + ": " + xNV);
			var newBr = document.createElement("br");
			// ggf. Bild einfuegen
			xNV = xNV.replace(/\s/,"");
			if(xNV.search(/.jpg$/) != -1 || xNV.search(/.jpeg$/) != -1){
				xNV = xNV.replace(/^images\//,"");
				var newImg = document.createElement("img");
			var newImgAlt = document.createAttribute("class");
			newImgAlt.nodeValue = "showTabRowImgPreview";
			newImg.setAttributeNode(newImgAlt);
			var newImgSrc = document.createAttribute("src");
			newImgSrc.nodeValue = "images/minSize/" + xNV;
			newImg.setAttributeNode(newImgSrc);
			sD.appendChild(newImg);
			}
			sD.appendChild(newEntry);
			sD.appendChild(newBr); 
		}
		xNode = xNode.nextSibling; }
	/* var x = 0, p = 40;
		if(document.all){p = p + document.body.scrollTop;}
		else if(document.getElementById){p = p + window.pageYOffset;}
		if(p<80) p = 80; 
		sD.style.top = p + "px";
		sD.style.right = "20px"; */
	tooltipFlag = true; xPosOffset = 30; yPosOffset = -10;
	showTabRowDelay = setTimeout("uncoverTooltip()",500);
}

function hideTabRowShowDiv(){
	hideTooltip();
}

// --------------------------------- DB-Nutzung -------------------------------

var lastEntryObj, openTreeExpires = 30;

// Wechsel der CSS-Klasse; Uebergabe der ID + der beiden Classes (id,class2,class2)
function openTreeEntry(x){
	if(typeof lastEntryObj == "object"){
		lastEntryObj.tHead.className = "thClose";
		lastEntryObj.tBody.className = "tbClose";
	}
	var h = document.getElementById("tHead" + x); 
	var b = document.getElementById("tBody" + x); 
	if(h && b){
		h.className = "thOpen"; 
		b.className = "tbOpen";
		lastEntryObj = {
			tHead : h,
			tBody : b
		};
	}
	if(openTreeExpires>0) setCookie("openTreeEntry",x,openTreeExpires);
}

function initTree(){
	execFctByClassName("thOpen",function(x){
		x.className = "thClose";
	});
	execFctByClassName("tbOpen",function(x){
		x.className = "tbClose";
	});
	openTreeEntryFromCookie();
}

function openTreeEntryFromCookie(){
	var x = getCookie("openTreeEntry");
	if(x!="") openTreeEntry(x);
}


// ------------------------------- Kleine Helferlein --------------------------

// Cookies holen
function getCookie(x){
	var k = document.cookie.split(";");
	for (var i = 0; i < k.length; ++i){
		k[i] = k[i].replace(/\s/,"");
		if(x==k[i].substr(0,k[i].search('='))) return k[i].substr(k[i].search('=')+1,k[i].length);
	}
	return "";
}

function setCookie(xName,xValue,expDays){
	var d = new Date(); d = new Date(d.getTime() + (expDays * 24 * 60 * 60 * 1000));
	document.cookie = xName + "=" + xValue + "; expires=" + d.toGMTString(); 
}

function killCookie(xName){
	document.cookie = xName + "=; ; expires=Thu, 01-Jan-70 00:00:01 GMT;";
}

// Funktion fuer Elemente mit einer bestimmten CSS-Klasse ausfuehren
function execFctByClassName(className,cFct){
	if(className == "" || typeof cFct != "function") return false;
	if(document.all)
		var ao = document.all;
  	else if(document.getElementsByTagName)
		var ao = document.getElementsByTagName("*");
	for(var i=0; i < ao.length; i++){
		if(ao[i].className.indexOf(className)!=-1) cFct(ao[i]);
	}
	return true;
}

// ----------------------------------------------------------------------------


